# Mapas mentais — passo a passo do deploy

## 1. Backend (repositório `batalha-de-historia` no GitHub)

Suba estes arquivos substituindo os que já existem (ou adicionando, nos novos):

- `server.py` → substitui o arquivo na raiz do repositório (mudança isolada:
  só foram acrescentadas as funções e rotas novas de mapas mentais, logo
  depois do `/api/tutor`; nada que já existia foi alterado).
- `admin.html` → vai para dentro da pasta `public/`, substituindo o que já
  existe (acrescenta só a 4ª aba "🧠 Mapas mentais").
- `importar_mapas_mentais.py` → novo arquivo, vai na raiz do repositório.
- `dados_mapas_mentais/` (pasta com `g6.json`, `g7.json`, `g8.json`,
  `g9.json`) → nova pasta, vai na raiz do repositório.

Nenhum outro arquivo do repositório precisa mudar. Os quizzes, a Jornada, as
salas e o tutor continuam exatamente como estavam.

Depois de subir e o Render terminar o redeploy automático:

### Importar os 41 mapas oficiais de Geografia (uma única vez)

No shell do Render (aba "Shell" do serviço `batalha-de-historia`), rode:

```
python3 importar_mapas_mentais.py
```

Isso grava os 41 mapas já como oficiais e aprovados (na mesma coleção que o
resto do site usa — Firestore se estiver configurado, senão um arquivo local
`mapas_mentais.json`, do mesmo jeito que as contribuições de professores já
funcionam). Pode rodar de novo sem medo: ele pula o que já foi importado.

### Variáveis de ambiente

Nenhuma variável nova é obrigatória — a rota nova (`/api/mapa`) usa a mesma
`GROQ_API_KEY` e `GROQ_MODEL` que já estão configuradas para o `/api/tutor`.
Se quiser ajustar o limite de mapas gerados por hora por IP (hoje 6/hora),
isso está direto no código, em `MAPA_RATE_LIMIT`/`MAPA_RATE_WINDOW` no
`server.py` — não precisa de variável de ambiente.

## 2. Site (Cloudflare Pages)

No painel do Cloudflare Pages do projeto, aba **Deployments** → **Create
deployment** (ou "New deployment") → arraste o arquivo `estudativa-site.zip`
(enviado junto com esta entrega) → publicar. Ele substitui o site inteiro
pela versão mais nova, que já inclui tudo o que foi entregue antes.

O que esse zip acrescenta (além de tudo que já existia):

- `/mapas-mentais/index.html` — biblioteca de mapas mentais (oficiais +
  comunidade, com filtro por disciplina e ano).
- `/mapas-mentais/criar/index.html` — página para criar um mapa mental novo.
- `/js/mindmap-engine.js` — o motor que desenha os mapas no navegador (mesmo
  layout aprovado do `gerar.py`).
- `/js/data/mapas-mentais-historia-oficiais.js` — lista dos 91 mapas de
  História que já existiam em `/img/mapas-mentais/` (gerada automaticamente
  a partir dos arquivos existentes, nenhuma imagem foi tocada).
- Um link novo "Mapas Mentais" no menu e um card na página inicial.

## 3. Teste rápido depois do deploy

1. Abra `/mapas-mentais/index.html` → aba "Mapas oficiais" → confira que
   os 91 mapas de História aparecem (isso não depende do backend) e, se já
   rodou a importação, que os 41 de Geografia também aparecem.
2. Abra `/mapas-mentais/criar/index.html` → gere um mapa de teste → confira
   se desenha certo e se os botões "Baixar PNG"/"Baixar PDF" funcionam.
3. No painel `/admin.html`, aba "🧠 Mapas mentais" → aprove ou rejeite o mapa
   de teste que você acabou de criar.

## Por que a geração por IA não foi testada ao vivo nesta entrega

Este ambiente onde eu trabalho não tem acesso de rede à API da Groq nem ao
seu backend no Render (só a alguns poucos serviços liberados), então não
consegui chamar `/api/mapa` de verdade por aqui. O que eu testei a fundo foi
a parte que decide se o mapa fica certo ou errado:

- a validação da ficha (4–6 ramos, 2–4 itens, tamanhos) — testada com casos
  válidos e inválidos, rejeitando corretamente cada um;
- o motor de desenho (o `mindmap-engine.js`) — testado de verdade num
  navegador (Playwright), com duas fichas de exemplo (uma de Geografia, uma
  de História), incluindo um bug real que encontrei e corrigi nas linhas
  curvas que ligam os ramos ao núcleo (ficavam erradas quando a página era
  exibida menor que o tamanho original). As duas imagens de exemplo geradas
  nesse teste foram enviadas junto com esta entrega.

Por isso, o passo 3 acima (gerar 1 mapa de teste de verdade, já com a IA)
precisa ser feito por você depois do deploy — é rápido, é a própria página
"Criar mapa mental" funcionando.
